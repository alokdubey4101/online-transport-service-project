/*create table book(book_id int not null primary key auto_increment, email varchar(255), dateofbook varchar(255), datemili varchar(255), address varchar(255), quantity varchar(255), date_at_want varchar(255), date_at_wantmili varchar(255), time_at_want varchar(255), address_at_want varchar(255), user_id int);
create table services(service_id int not null primary key auto_increment, city varchar(255), subCity varchar(255), truckCompany varchar(255), email varchar(255), bornb varchar(255));*/
create database transport;
use transport;


create table register(user_id int not null primary key auto_increment, name varchar(255), email varchar(255), password varchar(255), Address varchar(255), dob varchar(255));
create table book(book_id int not null primary key auto_increment, city varchar(255), subCity varchar(255), truckCompany varchar(255), bornb varchar(255), email varchar(255), dateofbook varchar(255), datemili varchar(255), address varchar(255), quantity varchar(255), date_at_want varchar(255), date_at_wantmili varchar(255), time_at_want varchar(255), address_at_want varchar(255), user_id int);
create table truck(truck_id int not null primary key auto_increment, available varchar(255), current varchar(255), booked varchar(255));
insert into truck(available, current, booked) values('0', '0' ,'0');
create table counts(id int not null primary key auto_increment, city varchar(255), subcity varchar(255), available varchar(255), booked varchar(255), current varchar(255));
create table addadmin(admin_id int not null primary key auto_increment, name varchar(255), email varchar(255), password varchar(255), phone varchar(255), address varchar(255));
insert into addadmin(name,  email, password, phone, address) values('Alok Dubey', 'alokdubey877@gmail.com', 'alokdubey4101', '9820695509', 'Thane');
create table feedback(id int not null primary key auto_increment, name varchar(255), email varchar(255), message text);


select * from counts where  subcity like 's%';
select * from counts;
select * from register;
select * from truck;
select * from addadmin;
select * from book;
select * from feedback;
select * from subCity;


update counts set booked='0' where id=10;
update counts set available='0' where id=10;
update counts set current='0' where id=10;


drop table feedback;
drop table truck;
drop table register;
drop table book;
drop table subcity;
drop table addadmin;