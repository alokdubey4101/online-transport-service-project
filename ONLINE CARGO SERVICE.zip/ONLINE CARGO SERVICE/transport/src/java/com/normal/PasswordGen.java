/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.normal;

/**
 *
 * @author ALOK
 */
public class PasswordGen {
    public static String password="";
    public String genrate(){
        char a[]={'A', 'B', 'C' , 'D', 'E', 'J', 'K', 'L', 'W', 'S', 'Q', '1', '2', '-', '|', '@', '8', '6', '+', 'P', 'M', '9', '4'};
        double first=Math.random()*(21-1+1);
        double second=Math.random()*(21-1+1);
        double third=Math.random()*(21-1+1);
        double fourth=Math.random()*(21-1+1);
        double fifth=Math.random()*(21-1+1);
        double sixth=Math.random()*(21-1+1);
        double seventh=Math.random()*(21-1+1);
        double eight=Math.random()*(21-1+1);
        int firstl=(int)first;
        int secondl=(int)second;
        int thirdl=(int)third;
        int fourthl=(int)fourth;
        int fifthl=(int)fifth;
        int sixthl=(int)sixth;
        int seventhl=(int)seventh;
        int eightl=(int)eight;
        password=a[firstl]+""+a[secondl]+""+a[thirdl]+""+a[fourthl]+""+a[fifthl]+""+a[sixthl]+""+a[seventhl]+""+a[eightl];
        return password;
    }
}
