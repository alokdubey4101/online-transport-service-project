package com.normal;

import java.util.ArrayList;
import java.util.List;
import java.sql.*;

public class SubCity {
    public List<String> subcity;
    public List<String> booked;
    public List<String> current;
    public List<String> available;
    public List<Integer> id;
    public List<String> city;
    public SubCity(){
        subcity=new ArrayList<>();
        booked=new ArrayList<>();
        current=new ArrayList<>();
        available=new ArrayList<>();
        id=new ArrayList<>();
        city=new ArrayList<>();
    }
    public void fetch(String city){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps=con.prepareStatement("select * from counts where city=?");
            ps.setString(1, city);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                subcity.add(rs.getString("subcity"));
                booked.add(rs.getString("booked"));
                current.add(rs.getString("current"));
                available.add(rs.getString("available"));
                id.add(rs.getInt("id"));
            }
            rs.close();
            ps.close();
            con.close();
        }catch(Exception e){System.out.println("SubCity.java: "+e);}
    }
    public void fetchby(String subcitys){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps=con.prepareStatement("select * from counts where subcity like ?");
            ps.setString(1, subcitys+'%');
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                subcity.add(rs.getString("subcity"));
                booked.add(rs.getString("booked"));
                current.add(rs.getString("current"));
                available.add(rs.getString("available"));
                id.add(rs.getInt("id"));
                city.add(rs.getString("city"));
            }
            rs.close();
            ps.close();
            con.close();
        }catch(Exception e){System.out.println("SubCity.java: "+e);}
    }
    public List<String> getAvailable(){
        return this.available;
    }
    public List<String> getBooked(){
        return this.booked;
    }
    public List<String> getCurrent(){
        return this.current;
    }
    public List<String> getSubcity(){
        return this.subcity;
    }
    public List<Integer> getId(){
        return this.id;
    }
    public List<String> getCity(){
        return this.city;
    }
}
