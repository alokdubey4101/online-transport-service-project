package com.servlet;

import com.google.gson.JsonObject;
import com.hiber.Addadmin;
import com.normal.Connect;
import com.normal.PasswordGen;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class add_admin extends HttpServlet {

    public static String cemail = "";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject jo = new JsonObject();
        PasswordGen pg = new PasswordGen();
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String branch = request.getParameter("branch");
        String password = pg.genrate();
        check(email);
        String femail=getEmail();
        System.out.println("-----------------"+femail);
        if (!email.equals(femail)){
            try {
                Addadmin aa = new Addadmin(name, email, password, phone, branch);
                SessionFactory sf = new Configuration().configure().buildSessionFactory();
                Session se = sf.openSession();
                Transaction tr = se.beginTransaction();
                se.save(aa);
                tr.commit();
                se.close();
                sf.close();
                jo.addProperty("done", "yes");
                jo.addProperty("password", password);
                out.println(jo);
            } catch (HibernateException e) {
                System.out.println("add_admin.java: " + e);
            }
        }
        else{
            jo.addProperty("done", "no");
            out.println(jo);
        }
    }

    public void check(String email) {
        try {
            Connect co = new Connect();
            Connection con = co.db();
            PreparedStatement ps = con.prepareStatement("select * from addadmin where email=?");
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                add_admin.cemail = rs.getString("email");
            }
            ps.close();
            rs.close();
            con.close();
        } catch (SQLException e) {
            System.out.println("add_admin.java method: " + e);
        }
    }
    public String getEmail(){
        return add_admin.cemail;
    }
}
