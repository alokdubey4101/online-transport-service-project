package com.servlet;

import com.google.gson.JsonObject;
import com.hiber.Book;
import com.normal.Connect;
import com.normal.Count;
import com.normal.Trucks;
import com.normal.servicegs;
import com.normal.userdet;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.hibernate.cfg.Configuration;

public class book extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            JsonObject jo = new JsonObject();
            HttpSession session = request.getSession();
            userdet ud = new userdet();
            ud.db(session.getAttribute("email").toString());
            String date = request.getParameter("date");
            String time = request.getParameter("time");
            String quantity = request.getParameter("quantity");
            String add = request.getParameter("add");
            String deliver = request.getParameter("deliver");
            PrintWriter out = response.getWriter();
            Date da1 = new SimpleDateFormat("MM-dd-yyyy").parse(date);
            Date da = new Date();
            String cda = da + "";
            Trucks tr = new Trucks();
            Count co = new Count();
            servicegs sg = new servicegs();
            tr.dcurrent();
            tr.booked();
            co.dcurrentid(sg.getId());
            co.bookedid(sg.getId());
            String subcity = sg.getSubCity();
            int id = ud.getId();
            fetch(subcity, session.getAttribute("email").toString(), cda, da.getTime() + "", add, quantity, date, da1.getTime() + "", time, deliver, id);
            jo.addProperty("done", "yes");
            out.println(jo);
        } catch (IOException | ParseException e) {
            System.out.println("book.java: " + e);
        }
    }

    public void fetch(String subcity, String email, String dateofbook, String datemili, String address, String quantity, String date_at_want, String date_at_wantmili, String time_at_want, String address_at_want, int user_id) {
        try {
            Connect co = new Connect();
            Connection con = co.db();
            PreparedStatement ps = con.prepareStatement("select book_id from book where subCity=? and bornb='not booked'");
            ps.setString(1, subcity);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                int bookid = rs.getInt("book_id");
                upd(date_at_want, bookid, dateofbook, email, datemili, address, quantity, date_at_wantmili, time_at_want, address_at_want, user_id);
            }
            rs.close();
            ps.close();
            con.close();
        } catch (SQLException e) {
            System.out.println("book.java: " + e);
        }
    }

    public void upd(String date_at_want, int id, String datebook, String email, String datemili, String caddress, String quantity, String date_at_wantmili, String time_at_want, String address_at_want, int user_id) {
        try {
            Connect co = new Connect();
            Connection con = co.db();
            PreparedStatement ps1 = con.prepareStatement("update book set date_at_want=? where book_id=?");
            ps1.setString(1, date_at_want);
            ps1.setInt(2, id);
            PreparedStatement ps2 = con.prepareStatement("update book set dateofbook=? where book_id=?");
            ps2.setString(1, datebook);
            ps2.setInt(2, id);
            PreparedStatement ps3 = con.prepareStatement("update book set email=? where book_id=?");
            ps3.setString(1, email);
            ps3.setInt(2, id);
            PreparedStatement ps4 = con.prepareStatement("update book set bornb=? where book_id=?");
            ps4.setString(1, "booked");
            ps4.setInt(2, id);
            PreparedStatement ps5 = con.prepareStatement("update book set datemili=? where book_id=?");
            ps5.setString(1, datemili);
            ps5.setInt(2, id);
            PreparedStatement ps6 = con.prepareStatement("update book set address=? where book_id=?");
            ps6.setString(1, caddress);
            ps6.setInt(2, id);
            PreparedStatement ps7 = con.prepareStatement("update book set quantity=? where book_id=?");
            ps7.setString(1, quantity);
            ps7.setInt(2, id);
            PreparedStatement ps8 = con.prepareStatement("update book set date_at_wantmili=? where book_id=?");
            ps8.setString(1, date_at_wantmili);
            ps8.setInt(2, id);
            PreparedStatement ps9 = con.prepareStatement("update book set time_at_want=? where book_id=?");
            ps9.setString(1, time_at_want);
            ps9.setInt(2, id);
            PreparedStatement ps10 = con.prepareStatement("update book set address_at_want=? where book_id=?");
            ps10.setString(1, address_at_want);
            ps10.setInt(2, id);
            PreparedStatement ps11 = con.prepareStatement("update book set user_id=? where book_id=?");
            ps11.setInt(1, user_id);
            ps11.setInt(2, id);
            int ids1 = ps1.executeUpdate();
            int ids2 = ps2.executeUpdate();
            int ids3 = ps3.executeUpdate();
            int ids4 = ps4.executeUpdate();
            int ids5 = ps5.executeUpdate();
            int ids6 = ps6.executeUpdate();
            int ids7 = ps7.executeUpdate();
            int ids8 = ps8.executeUpdate();
            int ids9 = ps9.executeUpdate();
            int ids10 = ps10.executeUpdate();
            int ids11 = ps11.executeUpdate();
            ps1.close();
            ps2.close();
            ps3.close();
            ps4.close();
            ps5.close();
            ps6.close();
            ps7.close();
            ps8.close();
            ps9.close();
            ps10.close();
            ps11.close();
            con.close();
        } catch (SQLException e) {
            System.out.println("book.java: " + e);
        }
    }
}
