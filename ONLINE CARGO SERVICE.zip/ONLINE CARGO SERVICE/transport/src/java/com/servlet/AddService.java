package com.servlet;

import com.google.gson.JsonObject;
import com.hiber.Book;
import com.normal.Count;
import com.normal.Trucks;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class AddService extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{
        PrintWriter out=response.getWriter();
        HttpSession session=request.getSession();
        Count co=new Count();
        Trucks tr=new Trucks();
        String name=request.getParameter("name");
        String dist=request.getParameter("dist");
        String tal=request.getParameter("tal");
        JsonObject jo=new JsonObject();
        Book bo=new Book(dist, tal, name, "not booked", "none", "none", "none", "none", "none", "none", "none", "none", "none", 0);
        Configuration con=new Configuration();
        SessionFactory sf=con.configure().buildSessionFactory();
        Session ses=sf.openSession();
        Transaction tran=ses.beginTransaction();
        ses.save(bo);
        tran.commit();
        ses.close();
        co.available(tal);
        co.current(tal);
        tr.available();
        tr.current();
        jo.addProperty("done", "yes");
        out.println(jo);
    }
}
