package com.servlet;

import com.google.gson.JsonObject;
import com.normal.Connect;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Alogin extends HttpServlet {
    static String femail="";
    static String fpass="";
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{
        HttpSession session=request.getSession();
        JsonObject jo=new JsonObject();
        PrintWriter out=response.getWriter();
        String email=request.getParameter("email");
        String password=request.getParameter("password");
        cemail(email);
        String gemail=getEmail();
        String gpass=getPassword();
        if(!email.equals(gemail)){
            jo.addProperty("done", "no");
            out.println(jo);
        }
        else if(!password.equals(gpass)){
            jo.addProperty("done", "not");
            out.println(jo);
        }
        else{
            session.setAttribute("emails", email);
            jo.addProperty("done", "yes");
            out.println(jo);
        }
    }
    public void cemail(String email){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps=con.prepareStatement("select * from addadmin where email=?");
            ps.setString(1, email);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                femail=rs.getString("email");
                fpass=rs.getString("password");
            }
        }
        catch(Exception e){
            System.out.println("Alogin.java: "+e);
        }
    }
    public String getEmail(){
        return Alogin.femail;
    }
    public String getPassword(){
        return Alogin.fpass;
    }
}
