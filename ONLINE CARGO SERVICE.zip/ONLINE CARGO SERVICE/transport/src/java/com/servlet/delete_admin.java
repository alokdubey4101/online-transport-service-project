package com.servlet;

import com.normal.Connect;
import java.sql.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class delete_admin extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response){
        int id=Integer.parseInt(request.getParameter("id"));
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps=con.prepareStatement("delete from addadmin where admin_id=?");
            ps.setInt(1, id);
            int ids=ps.executeUpdate();
            if(ids==1){
                RequestDispatcher rd=request.getRequestDispatcher("delete_admin.jsp");
                rd.include(request, response);
            }
            ps.close();
            con.close();
        }catch(Exception e){
            System.out.println("delete_admin.java: "+e);
        }
    }
}
