package com.servlet;

import com.google.gson.JsonObject;
import com.normal.Connect;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Update extends HttpServlet {
    PreparedStatement ps=null;
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{
        JsonObject jo=new JsonObject();
        PrintWriter out=response.getWriter();
        HttpSession session=request.getSession();
        String name=request.getParameter("name");
        String pass=request.getParameter("pass");
        String add=request.getParameter("add");
        String dob=request.getParameter("dob");
        try{
            Connect co=new Connect();
            Connection con=co.db();
            if(!name.equals("")){
                ps=con.prepareStatement("update register set name=? where email=?");
                ps.setString(1, name);
                ps.setString(2, session.getAttribute("email").toString());
            }
            if(!pass.equals("")){
                ps=con.prepareStatement("update register set password=? where email=?");
                ps.setString(1, pass);
                ps.setString(2, session.getAttribute("email").toString());
            }
            if(!add.equals("")){
                ps=con.prepareStatement("update register set Address=? where email=?");
                ps.setString(1, add);
                ps.setString(2, session.getAttribute("email").toString());
            }
            if(!dob.equals("")){
                ps=con.prepareStatement("update register set dob=? where email=?");
                ps.setString(1, dob);
                ps.setString(2, session.getAttribute("email").toString());
            }
            int id=ps.executeUpdate();
            if(id==1){
                jo.addProperty("done", "yes");
                out.println(jo);
            }
            ps.close();
            con.close();
        }
        catch(SQLException e){
            System.out.println("The Update.java: "+e);
        }
    }
}
