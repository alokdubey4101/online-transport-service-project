$(document).ready(function () {
    $('.dist').click(function ()
    {
        var dist = $('.dist').val();
        if (dist === 'Pune')
        {
            $('.tom').html("<label><b>Select the taluka</b></label><br><select class='tal'>\n\
                        <option value='-----select-choice-----'>-----select-choice-----</option>\n\
                        <option value='Chakan'>Chakan</option>\n\
                        <option value='Sanaswadi'>Sanaswadi</option>\n\
                        <option value='Ranjangaon'>Ranjangaon</option>\n\
                        <option valeu='Talegaon'>Talegaon</option>\n\
                        <option va;ue='Pimpari-Chinchwad'>Pimpari-Chinchwad</option>\n\
                        <option value='Hinjewadi'>Hinjewadi</option>\n\
                        <option value='Pirangul'>Pirangul</option></select><br><span class='talspan'></span><br>");

        } else if (dist === 'Mumbai')
        {
            $('.tom').html("<label><b>Select the taluka</b></label><br><select class='tal'>\n\
                        <option value='-----select-choice-----'>-----select-choice-----</option>\n\
                        <option value='Asan Gaav'>Asan Gaav</option>\n\
                        <option value='Vasai'>Vasai</option>\n\
                        <option value='Bhiwandi-Thane'>Bhiwandi-Thane</option></select><br><span class='talspan'></span><br>");
        } else if (dist === 'Navi Mumbai')
        {
            $('.tom').html("<label><b>Select the taluka</b></label><br><select class='tal'>\n\
                        <option value='-----select-choice-----'>-----select-choice-----</option>\n\
                        <option value='Panvel'>Panvel</option>\n\
                        <option value='Kalamboli'>Kalamboli</option>\n\
                        <option value='Talaja'>Talaja</option></select><br><span class='talspan'></span><br>");
        } else
        {
            $('.tom').html("<label><b>Select the taluka</b></label><br><select class='tal'>\n\
                        <option value='-----select-choice-----'>-----select-choice-----</option></select><br><span class='talspan'></span><br>");
        }
    });
    $('.but').click(function () {
        var n = $('.namespan');
        var d = $('.distspan');
        var t = $('.talspan');
        var name = $('.name').val();
        var dist = $('.dist').val();
        var tal = $('.tal').val();
        $('.but').hide();
        $('.rol').html('<img src=\"roller/roller.gif\"/>');
        if (name.trim() === '')
        {
            n.css('color', 'red');
            n.html('Enter the truck name please');
            n.css('boder-color', 'red');
            d.css('border-color', '');
            d.html('');
            t.css('border-color', '');
            t.html('');
            $('.but').show();
            $('.rol').html('');
        } else if (dist === '-----select-choice-----')
        {
            d.css('color', 'red');
            d.html('please choose any option');
            d.css('boder-color', 'red');
            n.css('border-color', '');
            n.html('');
            t.css('border-color', '');
            t.html('');
            $('.but').show();
            $('.rol').html('');
        } else if (tal === '-----select-choice-----')
        {
            t.css('color', 'red');
            t.html('please choose any option');
            t.css('boder-color', 'red');
            n.css('border-color', '');
            n.html('');
            d.css('border-color', '');
            d.html('');
            $('.but').show();
            $('.rol').html('');
        } else
        {
            t.css('color', '');
            t.html('');
            t.css('boder-color', 'red');
            n.css('border-color', '');
            n.html('');
            d.css('border-color', '');
            d.html('');
            $.ajax({
                url: 'AddService',
                type: 'POST',
                data: {name: name, dist: dist, tal: tal},
                success: function (result) {
                    var op = JSON.parse(result);
                    if (op.done === 'yes')
                    {
                        $('.but').show();
                        $('.rol').html('');
                        $(location).attr('href', 'service_suc.html');
                    }
                }
            });
        }
    });
});