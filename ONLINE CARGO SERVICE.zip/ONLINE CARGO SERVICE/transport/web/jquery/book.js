$(document).ready(function () {
    $('.date').datepicker({
        dateFormat: 'mm-dd-yy'
    });
    $('.but').click(function () {
        var datec = $('.date');
        var dates = $('.datespan');
        var timec = $('.time');
        var times = $('.timespan');
        var quantityc = $('input[name=same]:checked');
        var quantitys = $('.quantityspan');
        var addc = $('.add');
        var adds = $('.addspan');
        var deliverc = $('.deliver');
        var delivers = $('.deliverspan');
        var date = $('.date').val();
        var time = $('.time').val();
        var quantity = $('input[name=same]:checked').val();
        var add = $('.add').val();
        var deliver = $('.deliver').val();
        $('.but').hide();
        $('.rol').html('<img src=\"roller/roller.gif\"/>');
        var cdate=new Date();
        var bdate=new Date(date);
        var bmili=bdate.getTime();
        var cmilli=cdate.getTime();
        if (date.trim() === '')
        {
            dates.css('color', 'red');
            dates.html('Enter the date please');
            times.html('');
            quantitys.html('');
            adds.html('');
            delivers.html('');
            datec.css('border-color', 'red');
            timec.css('border-color', '');
            quantityc.css('border-color', '');
            addc.css('border-color', '');
            deliverc.css('border-color', '');
            $('.but').show();
            $('.rol').html('');
        }
        else if(bmili<cmilli){
            alert('booking date is less than current date');
            $('.but').show();
            $('.rol').html('');
        }
        else if(bmili===cmilli){
            alert('you can\'t book a service at current date');
            $('.but').show();
            $('.rol').html('');
        }
        else if (time.trim() === '') {
            times.css('color', 'red');
            dates.html('');
            times.html('Enter the Time please');
            quantitys.html('');
            adds.html('');
            delivers.html('');
            datec.css('border-color', '');
            timec.css('border-color', 'red');
            quantityc.css('border-color', '');
            addc.css('border-color', '');
            deliverc.css('border-color', '');
            $('.but').show();
            $('.rol').html('');
        } else if (!quantity) {
            alert('please select the quntity');
            $('.but').show();
            $('.rol').html('');
        } else if (add.trim() === '') {
            adds.css('color', 'red');
            dates.html('');
            adds.html('Enter the address');
            quantitys.html('');
            times.html('');
            delivers.html('');
            datec.css('border-color', '');
            timec.css('border-color', '');
            quantityc.css('border-color', '');
            addc.css('border-color', 'red');
            deliverc.css('border-color', '');
            $('.but').show();
            $('.rol').html('');
        } else if (deliver.trim() === '') {
            delivers.css('color', 'red');
            dates.html('');
            delivers.html('Enter the deliver address');
            quantitys.html('');
            times.html('');
            adds.html('');
            datec.css('border-color', '');
            timec.css('border-color', '');
            quantityc.css('border-color', '');
            addc.css('border-color', '');
            deliverc.css('border-color', 'red');
            $('.but').show();
            $('.rol').html('');
        } else
        {
            delivers.css('color', 'red');
            dates.html('');
            delivers.html('');
            quantitys.html('');
            times.html('');
            adds.html('');
            datec.css('border-color', '');
            timec.css('border-color', '');
            quantityc.css('border-color', '');
            addc.css('border-color', '');
            deliverc.css('border-color', '');
            $.ajax({
                url: 'book',
                type: 'POST',
                data: {date: date, time: time, quantity: quantity, add: add, deliver: deliver},
                success: function (result) {
                    var op = JSON.parse(result);
                    if (op.done === 'yes') {
                        $('.but').show();
                        $('.rol').html('');
                        $(location).attr('href', 'home.jsp');
                    }
                }
            });
        }
    });
});