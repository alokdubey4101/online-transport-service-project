$(document).ready(function(){
    $('.dob').datepicker({
    dateFormat:'mm-dd-yy',
    changeMonth:true,
    changeYear:true,
    maxDate: '8Y',
    minDate: '-18Y'
    });
    $('.cpassword').keyup(function(){
        var password=$('.password').val();
        var cpassword=$('.cpassword').val();
        if(password!==cpassword)
        {
            $('.cpassword').css('border-color','red');
            $('.cpasswordspan').css('color', 'red');
            $('.cpasswordspan').html('invalid');
        }else
        {
            $('.cpassword').css('border-color','');
            $('.cpasswordspan').css('color', 'green');
            $('.cpasswordspan').html('valid');
        }
    });
    $('.but').click(function(){
        var name=$('.name').val();
        var email=$('.email').val();
        var password=$('.password').val();
        var add=$('.add').val();
        var dob=$('.dob').val();
        var cpass=$('.cpassword').val();
        $('.but').hide();
        $('.roll').html('<img src=\"roller/roller.gif\"/>');
        if(name.trim()==='')
        {
            $('.email').css('border-color', '');
            $('.password').css('border-color','');
            $('.cpassword').css('border-color','');
            $('.add').css('border-color','');
            $('.dob').css('border-color','');
            $('.name').css('border-color','red');
            $('.namespan').css('color', 'red');
            $('.namespan').html('Enter your Name');
            $('.passwordspan').html('');
            $('.cpasswordspan').html('');
            $('.addspan').html('');
            $('.emailspan').html('');
            $('.dobspan').html('');
            $('.but').show();
            $('.roll').html('');
        }
        else if(email.trim()==='')
        {
            $('.email').css('border-color', 'red');
            $('.password').css('border-color','');
            $('.cpassword').css('border-color','');
            $('.add').css('border-color','');
            $('.dob').css('border-color','');
            $('.email').css('border-color','');
            $('.emailspan').css('color', 'red');
            $('.namespan').html('');
            $('.passwordspan').html('');
            $('.cpasswordspan').html('');
            $('.addspan').html('');
            $('.emailspan').html('Enter your E-mail');
            $('.dobspan').html('');
            $('.but').show();
            $('.roll').html('');
        }
        else if(password.trim()==='')
        {
            $('.email').css('border-color', '');
            $('.password').css('border-color','red');
            $('.cpassword').css('border-color','');
            $('.add').css('border-color','');
            $('.dob').css('border-color','');
            $('.email').css('border-color','');
            $('.passwordspan').css('color', 'red');
            $('.namespan').html('');
            $('.passwordspan').html('Enter the Password');
            $('.cpasswordspan').html('');
            $('.addspan').html('');
            $('.emailspan').html('');
            $('.dobspan').html('');
            $('.but').show();
            $('.roll').html('');
        }
        else if(add.trim()==='')
        {
            $('.email').css('border-color', '');
            $('.password').css('border-color','');
            $('.cpassword').css('border-color','');
            $('.add').css('border-color','red');
            $('.dob').css('border-color','');
            $('.email').css('border-color','');
            $('.addspan').css('color', 'red');
            $('.namespan').html('');
            $('.passwordspan').html('');
            $('.cpasswordspan').html('');
            $('.addspan').html('Enter the Address');
            $('.emailspan').html('');
            $('.dobspan').html('');
            $('.but').show();
            $('.roll').html('');
        }
        else if(dob.trim()==='')
        { 
            $('.email').css('border-color', '');
            $('.password').css('border-color','');
            $('.cpassword').css('border-color','');
            $('.add').css('border-color','');
            $('.dob').css('border-color','red');
            $('.email').css('border-color','');
            $('.dobspan').css('color', 'red');
            $('.namespan').html('');
            $('.passwordspan').html('');
            $('.cpasswordspan').html('');
            $('.addspan').html('');
            $('.emailspan').html('');
            $('.dobspan').html('Enter the Date of birth');
            $('.but').show();
            $('.roll').html('');
        }
        else if(cpass.trim()==='')
        {
            $('.email').css('border-color', '');
            $('.password').css('border-color','');
            $('.cpassword').css('border-color','red');
            $('.add').css('border-color','');
            $('.dob').css('border-color','');
            $('.email').css('border-color','');
            $('.cpasswordspan').css('color', 'red');
            $('.namespan').html('');
            $('.passwordspan').html('');
            $('.cpasswordspan').html('Please Confimr your password');
            $('.addspan').html('');
            $('.emailspan').html('');
            $('.dobspan').html('');
            $('.but').show();
            $('.roll').html('');
        }
        else if(cpass!==password)
        {
            $('.email').css('border-color', '');
            $('.password').css('border-color','');
            $('.cpassword').css('border-color','red');
            $('.add').css('border-color','');
            $('.dob').css('border-color','');
            $('.email').css('border-color','');
            $('.cpasswordspan').css('color', 'red');
            $('.namespan').html('');
            $('.passwordspan').html('');
            $('.cpasswordspan').html('Password didn\'t matched');
            $('.addspan').html('');
            $('.emailspan').html('');
            $('.dobspan').html('');
            $('.but').show();
            $('.roll').html('');
        }
        else 
        {
            $('.email').css('border-color', '');
            $('.password').css('border-color','');
            $('.cpassword').css('border-color','');
            $('.add').css('border-color','');
            $('.dob').css('border-color','');
            $('.email').css('border-color','');
            $('.cpasswordspan').css('color', '');
            $('.namespan').html('');
            $('.passwordspan').html('');
            $('.cpasswordspan').html('');
            $('.addspan').html('');
            $('.emailspan').html('');
            $('.dobspan').html('');
            $.ajax({
                url:'Usignup',
                type:'POST',
                data:{name:name, password:password, email:email, add:add, dob:dob},
                success:function(result){
                    var op=JSON.parse(result);
                    if(op.done==='no')
                    {
                        $('.email').css('border-color', 'red');
                        $('.password').css('border-color', '');
                        $('.cpassword').css('border-color', '');
                        $('.add').css('border-color', '');
                        $('.dob').css('border-color', '');
                        $('.email').css('border-color', '');
                        $('.emailspan').css('color', 'red');
                        $('.namespan').html('');
                        $('.passwordspan').html('');
                        $('.cpasswordspan').html('');
                        $('.addspan').html('');
                        $('.emailspan').html('Sorry the E-mail is already Present');
                        $('.dobspan').html('');
                        $('.but').show();
                        $('.roll').html('');
                    }
                    if(op.done==='yes')
                    {
                        $(location).attr('href', 'success.html');
                    }
                }
            });
        }
    });
});